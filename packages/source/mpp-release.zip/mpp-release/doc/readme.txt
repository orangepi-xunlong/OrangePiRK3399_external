Media Process Platform document directory description

Mpp document is separated into two parts:

1. Mpp user guide and user manual for library user
This part contains information about how to use mpp and external study resource
besides source code.

2. Mpp design document for developer
This part contains information about design principle, module design and other
information which will benefit developer further understand.

